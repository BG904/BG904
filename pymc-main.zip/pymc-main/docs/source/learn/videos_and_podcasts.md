(videos_and_podcasts)=
# Videos and Podcasts

:::{card} PyMC Developers Youtube channel

[See all videos here](https://www.youtube.com/c/PyMCDevelopers/videos)
:::

:::{card} PyMC talks

Actively curated [YouTube playlist](https://www.youtube.com/playlist?list=PL1Ma_1DBbE82OVW8Fz_6Ts1oOeyOAiovy) of PyMC talks
:::

:::{card} PyMC Labs Youtube channel

[See all videos here](https://www.youtube.com/c/PyMCLabs/videos)
:::

:::{card} PyMCon 2020 talks

[See all videos here](https://www.youtube.com/playlist?list=PLD1x-BW9UdeG68AQj6rDRfGiFFrpZ3cgu)
:::

:::{card} Learning Bayesian Statistics podcast

[See all videos here](https://www.youtube.com/channel/UCAwVseuhVrpJFfik_cMHrhQ/videos)
:::
