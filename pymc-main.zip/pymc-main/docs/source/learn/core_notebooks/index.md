(core_notebooks)=
# Notebooks on core features

:::{toctree}
:maxdepth: 1

pymc_overview
GLM_linear
model_comparison
posterior_predictive
dimensionality
pymc_pytensor
:::
