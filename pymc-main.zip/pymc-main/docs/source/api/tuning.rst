Tuning
------

.. currentmodule:: pymc

.. autosummary::
   :toctree: generated/

   find_hessian
   guess_scaling
   trace_cov
   find_MAP
