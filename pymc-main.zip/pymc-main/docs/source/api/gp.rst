Gaussian Processes
------------------

.. automodule:: pymc.gp

.. toctree::

   gp/implementations
   gp/mean
   gp/cov
