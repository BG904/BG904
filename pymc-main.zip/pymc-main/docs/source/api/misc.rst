Other utils
***********

.. currentmodule:: pymc

.. autosummary::
   :toctree: generated/

   compute_log_likelihood
   find_constrained_prior
   DictToArrayBijection

Printing
--------
.. autosummary::
   :toctree: generated/

   str_for_dist
   str_for_model
   str_for_potential_or_deterministic
