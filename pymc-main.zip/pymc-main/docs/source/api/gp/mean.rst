**************
Mean Functions
**************

.. automodule:: pymc.gp.mean
.. autosummary::
   :toctree: generated

   Zero
   Constant
   Linear
