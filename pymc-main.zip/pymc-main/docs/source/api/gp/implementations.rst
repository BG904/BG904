***************
Implementations
***************

.. currentmodule:: pymc.gp
.. autosummary::
   :toctree: generated

   Latent
   LatentKron
   Marginal
   MarginalKron
   MarginalApprox
   TP
