**************************************
Ordinary differential equations (ODEs)
**************************************


.. automodule:: pymc.ode

.. autosummary::
    :toctree: generated/

    DifferentialEquation
