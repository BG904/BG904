*******
Mixture
*******

.. currentmodule:: pymc
.. autosummary::
   :toctree: generated

   Mixture
   NormalMixture
