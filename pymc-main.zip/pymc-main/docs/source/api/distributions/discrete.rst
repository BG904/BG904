********
Discrete
********

.. currentmodule:: pymc
.. autosummary::
   :toctree: generated

   Binomial
   BetaBinomial
   Bernoulli
   DiscreteWeibull
   Poisson
   NegativeBinomial
   DiracDelta
   ZeroInflatedPoisson
   ZeroInflatedBinomial
   ZeroInflatedNegativeBinomial
   DiscreteUniform
   Geometric
   HyperGeometric
   Categorical
   OrderedLogistic
   OrderedProbit
