********
Censored
********

.. currentmodule:: pymc
.. autosummary::
   :toctree: generated

   Censored
