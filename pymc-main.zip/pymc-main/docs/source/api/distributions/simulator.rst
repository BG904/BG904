**********
Simulator
**********

.. currentmodule:: pymc
.. autosummary::
   :toctree: generated

   Simulator
