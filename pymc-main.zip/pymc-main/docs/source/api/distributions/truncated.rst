*********
Truncated
*********

.. currentmodule:: pymc
.. autosummary::
   :toctree: generated

   Truncated
