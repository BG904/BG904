**********
Timeseries
**********

.. currentmodule:: pymc
.. autosummary::
   :toctree: generated

    AR
    GaussianRandomWalk
    GARCH11
    EulerMaruyama
    MvGaussianRandomWalk
    MvStudentTRandomWalk
