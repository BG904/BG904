**********************
Distribution utilities
**********************

.. currentmodule:: pymc
.. autosummary::
   :toctree: generated/

    Distribution
    Discrete
    Continuous
    CustomDist
    SymbolicRandomVariable
