Data
****

.. currentmodule:: pymc

.. autosummary::
   :toctree: generated/

   ConstantData
   MutableData
   get_data
   Data
   GeneratorAdapter
   Minibatch
